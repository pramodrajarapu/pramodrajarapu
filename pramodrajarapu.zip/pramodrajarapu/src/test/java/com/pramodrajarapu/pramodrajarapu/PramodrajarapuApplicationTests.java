package com.pramodrajarapu.pramodrajarapu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PramodrajarapuApplicationTests {

	@Test
	void contextLoads() {
	}

}
